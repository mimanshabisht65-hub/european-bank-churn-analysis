import streamlit as st
import pandas as pd
import numpy as np

st.set_page_config(page_title="European Bank Customer Churn Analytics", page_icon="🏦", layout="wide")

@st.cache_data
def load_data():
    df = pd.read_csv("European_Bank.csv")
    df["Age Group"] = pd.cut(df["Age"], [-np.inf, 29, 45, 60, np.inf], labels=["<30", "30–45", "46–60", "60+"])
    df["Credit Score Band"] = pd.cut(df["CreditScore"], [-np.inf, 579, 669, np.inf], labels=["Low", "Medium", "High"])
    df["Tenure Group"] = pd.cut(df["Tenure"], [-np.inf, 2, 5, np.inf], labels=["New", "Mid-term", "Long-term"])
    df["Balance Segment"] = np.select(
        [df["Balance"].eq(0), df["Balance"].gt(0) & df["Balance"].lt(100000), df["Balance"].ge(100000)],
        ["Zero-balance", "Low-balance", "High-balance"], default="Check")
    df["Churn Status"] = np.where(df["Exited"] == 1, "Churned", "Retained")
    df["Engagement Status"] = np.where(df["IsActiveMember"] == 1, "Active", "Inactive")
    df["High-Value Customer"] = np.where(df["Balance"] >= 100000, "Yes", "No")
    return df

df = load_data()
st.title("🏦 European Bank Customer Churn Analytics")
st.caption("Customer-level churn, segmentation and financial exposure analysis")

st.sidebar.header("Segment Filters")
def pick(label, col):
    opts = sorted(df[col].dropna().astype(str).unique())
    return st.sidebar.multiselect(label, opts, default=list(opts))

geos = pick("Geography", "Geography")
genders = pick("Gender", "Gender")
ages = pick("Age Group", "Age Group")
credits = pick("Credit Score Band", "Credit Score Band")
tenures = pick("Tenure Group", "Tenure Group")
balances = pick("Balance Segment", "Balance Segment")
engagement = pick("Engagement", "Engagement Status")

f = df[
    df["Geography"].isin(geos) & df["Gender"].isin(genders) &
    df["Age Group"].astype(str).isin(ages) &
    df["Credit Score Band"].astype(str).isin(credits) &
    df["Tenure Group"].astype(str).isin(tenures) &
    df["Balance Segment"].isin(balances) &
    df["Engagement Status"].isin(engagement)
].copy()

total = len(f)
churned = int(f["Exited"].sum())
retained = total - churned
rate = churned / total if total else 0
high = f[f["High-Value Customer"] == "Yes"]
high_churn = int(high["Exited"].sum())
high_rate = high["Exited"].mean() if len(high) else 0
balance_risk = f.loc[f["Exited"] == 1, "Balance"].sum()

st.subheader("Overall Churn Summary")
c1,c2,c3,c4,c5,c6 = st.columns(6)
c1.metric("Customers", f"{total:,}")
c2.metric("Churned", f"{churned:,}")
c3.metric("Retained", f"{retained:,}")
c4.metric("Churn Rate", f"{rate:.2%}")
c5.metric("High-Value Churners", f"{high_churn:,}")
c6.metric("Balance at Risk", f"€{balance_risk:,.0f}")

tab1,tab2,tab3,tab4 = st.tabs(["🌍 Geography","👥 Age & Tenure","💰 High-Value Explorer","🔎 Detailed Data"])

with tab1:
    st.subheader("Geography-wise Churn")
    g = f.groupby("Geography").agg(Customers=("CustomerId","count"), Churned=("Exited","sum"), Avg_Balance=("Balance","mean")).reset_index()
    g["Churn Rate"] = g["Churned"]/g["Customers"]
    g["Geographic Risk Index"] = g["Churn Rate"]/rate*100 if rate else 0
    st.bar_chart(g.set_index("Geography")["Churn Rate"])
    st.dataframe(g.style.format({"Churn Rate":"{:.2%}","Avg_Balance":"€{:,.0f}","Geographic Risk Index":"{:.1f}"}), use_container_width=True)

with tab2:
    a,b = st.columns(2)
    with a:
        ag=f.groupby("Age Group",observed=False).agg(Customers=("CustomerId","count"),Churned=("Exited","sum")).reset_index()
        ag["Churn Rate"]=ag["Churned"]/ag["Customers"]
        st.subheader("Age Churn Comparison")
        st.bar_chart(ag.set_index("Age Group")["Churn Rate"])
        st.dataframe(ag.style.format({"Churn Rate":"{:.2%}"}),use_container_width=True)
    with b:
        t=f.groupby("Tenure Group",observed=False).agg(Customers=("CustomerId","count"),Churned=("Exited","sum")).reset_index()
        t["Churn Rate"]=t["Churned"]/t["Customers"]
        st.subheader("Tenure Churn Comparison")
        st.bar_chart(t.set_index("Tenure Group")["Churn Rate"])
        st.dataframe(t.style.format({"Churn Rate":"{:.2%}"}),use_container_width=True)

with tab3:
    st.subheader("High-Value Customer Churn Explorer")
    hv=f[f["High-Value Customer"]=="Yes"]
    hvc=hv[hv["Exited"]==1]
    a,b,c=st.columns(3)
    a.metric("High-Value Customers",f"{len(hv):,}")
    b.metric("High-Value Churners",f"{len(hvc):,}")
    c.metric("High-Value Churn Rate",f"{hv.Exited.mean():.2%}" if len(hv) else "0.00%")
    st.write("High-value is defined as Balance ≥ €100,000.")
    if len(hv):
        hg=hv.groupby("Geography").agg(Customers=("CustomerId","count"),Churned=("Exited","sum"),Balance=("Balance","sum")).reset_index()
        hg["Churn Rate"]=hg["Churned"]/hg["Customers"]
        st.bar_chart(hg.set_index("Geography")["Churn Rate"])
        st.dataframe(hg.style.format({"Churn Rate":"{:.2%}","Balance":"€{:,.0f}"}),use_container_width=True)
    st.info("Balance at risk is an exposure proxy, not proven lost bank revenue.")

with tab4:
    st.subheader("Filtered Customer Records")
    st.dataframe(f.drop(columns=["Surname"],errors="ignore"),use_container_width=True,height=500)

st.divider()
st.subheader("Methodology & Sources")
st.write("Primary source: supplied customer-level European Bank churn dataset. Secondary source: European Central Bank (ECB) for European banking and financial context. ECB is not claimed as the source of these customer records.")
