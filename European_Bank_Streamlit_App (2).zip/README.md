# European Bank Customer Churn Streamlit App

Run locally:
`pip install -r requirements.txt`
`streamlit run app.py`

For deployment, upload `app.py`, `European_Bank.csv`, and `requirements.txt` to a GitHub repository and deploy it using Streamlit Community Cloud.
